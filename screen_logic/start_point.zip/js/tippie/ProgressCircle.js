;(function ($) {

    Tippie.ProgressCircle = function (config) {

        config = (config = config || {});

        this.Element = $(config.element);
        this.Max = $(config.max);
        //this.Element.html('<div class="percent"></div><div id="slice"><div class="pie"></div></div>');
    };

    Tippie.ProgressCircle.prototype = {

        Render: function (percent) {
            //this.Element.html('<div class="percent"></div><div id="slice"'+(percent > 50 ? ' class="gt50"':'')+'><div class="pie"></div>'+(percent > 50?'<div class="pie fill"></div>':'')+'</div>');
            this.Element.html('<div class="percent"></div><div id="slice"><div class="pie"></div></div>');

            if(percent >= 50)
            {

                this.Element.find('#slice').append('<div class="pie fill"></div>');
                this.Element.find('#slice').addClass('gt50');
            }
            else
            {
                this.Element.find('.fill').remove();
                this.Element.find('#slice').removeClass('gt50');
            }
           // this.Element.css('font-size', '50px');
            this.Element.find('#slice .pie').css({
                '-webkit-transform':'rotate('+ 360 / 100 * percent +'deg)'
            });

            this.Element.find('.percent').html(Math.round(percent)+'%');
        }
    };
})(jQuery);